# Import shortcut

To use Teams Clipboard Dialer on iOS, import the shortcut from [iCloud](https://www.icloud.com/shortcuts/3120aab673fb4ce28535f2357635d108).