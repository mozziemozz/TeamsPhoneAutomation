Link 1: https://icon-icons.com/icon/phone/153797
Link 2: https://icon-icons.com/icon/my-phone/153791
License: https://icon-icons.com/license

2023-10-23
Free icon-icons license (WITH ATTRIBUTION)

This license allows you to use for free any of icon-icons contents for your projects as long as they are attributed to their author in the definitive project.
Where you can use icon-icons contents:
- Website.
- Software, applications, mobile, Multimedia
- Printed and digital media (magazines, newspapers, books, cards, labels, CD, television, video, e-mail).
- Advertisement and promotional items.
- Presentation of products and public events.
What you CAN DO:
- You have the non-exclusive, non-transferable, non-sublicensable right to use the licensed material an unlimited number of times in any and all media for the commercial or personal purposes listed above.
- You may alter and create derivative works.
- You can use icon-icons Contents during the rights period world wide.
- Share icon-icons content including direct link to download page.
What you CANNOT DO:
- Sublicense, sell or rent any contents (or a modified version of them).
- Include icon-icons Contents in an online or offline database.
- Offering icon-icons Contents designs (or modified icon-icons Contents versions) for download.